<?php
session_start();
include 'db_connect.php'; // Include your database connection here

$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize input data
    $firstName = htmlspecialchars(trim($_POST['firstName']));
    $lastName = htmlspecialchars(trim($_POST['lastName']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $confirmPassword = htmlspecialchars(trim($_POST['confirmPassword']));
    $role = $_POST['role'];

    // For gym owners, capture additional gym details
    $gymName = isset($_POST['gymName']) ? htmlspecialchars(trim($_POST['gymName'])) : null;
    $gymContact = isset($_POST['gymContact']) ? htmlspecialchars(trim($_POST['gymContact'])) : null;
    $gymLocation = isset($_POST['gymLocation']) ? htmlspecialchars(trim($_POST['gymLocation'])) : null;
    $servicesOffered = isset($_POST['servicesOffered']) ? htmlspecialchars(trim($_POST['servicesOffered'])) : null;

    // Capture the preferred gym for trainees
    $preferredGym = isset($_POST['gymPreferred']) ? intval($_POST['gymPreferred']) : null;

    // Additional validation
    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Check if the email already exists
        $emailQuery = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($emailQuery);
        
        if (!$stmt) {
            die("Preparation failed: " . $conn->error);
        }

        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email already registered.";
        } else {
            // Insert user data into users table
            $query = "INSERT INTO users (username, email, password, role, gym_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $fullName = $firstName . ' ' . $lastName;

            if (!$stmt) {
                die("Preparation failed: " . $conn->error);
            }

            // Bind gym_id as NULL if user is gym_owner
            $gymIdToInsert = ($role == 'gym_owner') ? null : $preferredGym;
            $stmt->bind_param('ssssi', $fullName, $email, $hashedPassword, $role, $gymIdToInsert);

            if ($stmt->execute()) {
                $user_id = $stmt->insert_id; // Get the ID of the newly inserted user

                // If the user is a gym owner, insert gym details into gyms table
                if ($role == 'gym_owner' && $gymName && $gymContact && $gymLocation && $servicesOffered) {
                    $gymQuery = "INSERT INTO gyms (gym_name, gym_contact, gym_location, services_offered) VALUES (?, ?, ?, ?)";
                    $stmt = $conn->prepare($gymQuery);
                    $stmt->bind_param('ssss', $gymName, $gymContact, $gymLocation, $servicesOffered);
                    if (!$stmt->execute()) {
                        die("Gym insertion failed: " . $stmt->error);
                    }
                }

                // Registration successful, redirect to login
                header('Location: login.php');
                exit();
            } else {
                $error = "Error: " . mysqli_error($conn);
            }
        }
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../static/css/nav.css">
    <link rel="stylesheet" href="../static/css/sign-up.css">
    <script src="../static/scripts/sign-up.js" defer></script>
    <title>FitFlex | Sign-up Page</title>
</head>
<body>
    
    <!-- Navigation Section -->
    <header class="header">
        <div><a href="./index.php"><img class="logo" src="../static/images/FitFlex.png" alt="website logo" width="70px"></a></div>
        <div class="hamburger">
            <div class="menu-btn">
                <div class="menu-btn_lines"></div>
            </div>
        </div>
        <nav>
            <div class="nav_links">
                <ul class="menu-items">
                    <li><a href="./index.php" class="menu-item">Home</a></li>
                    <li><a href="./about.php" class="menu-item">About Us</a></li>
                    <li><button class="sign-in-btn"><a href="./login.php" class="menu-item">Login</a></button></li>
                    <li><button class="sign-in-btn"><a href="./sign-up.php" class="menu-item">Sign-up</a></button></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- End of Navigation Section -->

    <div class="container">
        <div class="banner-login"></div>
        <div class="right-content">
            <div class="header-wrapper">
                <div class="heading" style="color: #122331;"><h1>Create an Account</h1></div>
            </div>

            <div class="inner-container">
                <form id="registerForm" method="POST" action="sign-up.php">
                    <?php if (!empty($error)): ?>
                        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <div><input class="input_area" type="text" name="firstName" placeholder="First Name" required></div>
                    <div id="firstNameError" class="error-message"></div>
                    
                    <div><input class="input_area" type="text" name="lastName" placeholder="Last Name" required></div>
                    <div id="lastNameError" class="error-message"></div>
                    
                    <div><input class="input_area" type="email" name="email" placeholder="Email" required></div>
                    <div id="emailError" class="error-message"></div>

                    <div><input class="input_area" type="password" name="password" placeholder="Password" required></div>
                    <div id="passwordError" class="error-message"></div>

                    <div><input class="input_area" type="password" name="confirmPassword" placeholder="Confirm Password" required></div>
                    <div id="confirmPasswordError" class="error-message"></div>

                    <div class="select-role">
                        <label for="role">Select role:</label><br>
                        <input type="radio" id="gymOwner" name="role" value="gym_owner" required>
                        <label for="gymOwner" style="margin-right: 20px;">Gym Owner</label>
                        <input type="radio" id="trainee" name="role" value="trainee" required>
                        <label for="trainee">Trainee (Gym user)</label><br><br>
                    </div>

                    <!-- Hidden fields to capture gym owner details -->
                    <input type="hidden" name="gymName" id="gymNameHidden">
                    <input type="hidden" name="gymContact" id="gymContactHidden">
                    <input type="hidden" name="gymLocation" id="gymLocationHidden">
                    <input type="hidden" name="servicesOffered" id="servicesOfferedHidden">

                    <div><input class="submit_btn" type="submit" value="Register"></div>
                    <div class="create"><p>Already have an account?</p> <a href="./login.php">Login</a></div>
                </form>
            </div>
        </div>        
    </div>

    <br>
    <br>

    <!-- Gym Owner Modal -->
    <div id="gymOwnerModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Gym Owner Details</h2>
            <form id="gymOwnerForm">
                <div><input class="input_area" type="text" id="gymName" name="gymName" placeholder="Gym Name" required></div>
                <div><input class="input_area" type="text" id="gymContact" name="gymContact" placeholder="Contact Details" required></div>
                <div><input class="input_area" type="text" id="gymLocation" name="gymLocation" placeholder="Gym Location" required></div>
                <div><input class="input_area" type="text" id="servicesOffered" name="servicesOffered" placeholder="Services Offered" required></div>
                <button type="button" id="gymOwnerDone">Done</button>
            </form>
        </div>
    </div>

    <!-- Trainee Modal -->
    <div id="traineeModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Trainee Gym Details</h2>
            <form id="traineeForm">
             
                <div>
                    <label for="gymPreferred">Select Your Preferred Gym:</label>
                    <select class="input_area" id="gymPreferred" name="gymPreferred" required>
                        <option value="">-- Select a Gym --</option>
                        <?php
                        $sql = "SELECT gym_id, gym_name FROM gyms";
                        if ($result = $conn->query($sql)) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . htmlspecialchars($row['gym_id']) . '">' . htmlspecialchars($row['gym_name']) . '</option>';
                            }
                        } else {
                            echo '<option value="">Error fetching gyms</option>'; 
                        }
                        ?>
                    </select>
                </div>


                <button type="button" id="traineeDone">Done</button>
            </form>
        </div>
    </div>

    <script>
        // JavaScript to handle modal logic
        document.getElementById('gymOwner').addEventListener('click', function () {
            document.getElementById('gymOwnerModal').style.display = 'block';
        });

        document.getElementById('trainee').addEventListener('click', function () {
            document.getElementById('traineeModal').style.display = 'block';
        });

        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', function () {
                document.getElementById('traineeModal').style.display = 'none';
                document.getElementById('gymOwnerModal').style.display = 'none';
            });
        });

        // Capture gym owner details
        document.getElementById('gymOwnerDone').addEventListener('click', function () {
            const gymName = document.getElementById('gymName').value;
            const gymContact = document.getElementById('gymContact').value;
            const gymLocation = document.getElementById('gymLocation').value;
            const servicesOffered = document.getElementById('servicesOffered').value;

            document.getElementById('gymNameHidden').value = gymName;
            document.getElementById('gymContactHidden').value = gymContact;
            document.getElementById('gymLocationHidden').value = gymLocation;
            document.getElementById('servicesOfferedHidden').value = servicesOffered;

            document.getElementById('gymOwnerModal').style.display = 'none';
        });

        // Capture trainee gym preference
        document.getElementById('traineeDone').addEventListener('click', function () {
            const preferredGym = document.getElementById('gymPreferred').value;

            // Handle the preferred gym selection as needed
            // For now, you can simply close the modal
            document.getElementById('traineeModal').style.display = 'none';
        });
    </script>
</body>
</html>
