<?php
session_start(); // Start the session

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php'; // Include your database connection file

// Initialize an error variable
$error = "";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the submitted form data
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role']; // Get the selected role (gym owner or trainee)

    // Validation
    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        // Prepare the SQL query to check the user
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = ?");
        $stmt->bind_param('ss', $email, $role);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Verify password if user exists
        if ($user && password_verify($password, $user['password'])) {
            // Successful login, set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_type'] = $user['role']; // gym_owner or trainee

            // Check if header function is working
            if (headers_sent()) {
                echo "Headers already sent. Cannot redirect.";
            } else {
                header('Location: dashboard.php');
                exit();
            }
        } else {
            // More specific error messages
            if ($result->num_rows == 0) {
                $error = "Invalid email or role.";
            } else {
                $error = "Invalid password.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../static/css/nav.css">
    <link rel="stylesheet" href="../static/css/login.css">
    <title>FitFlex | Login Page</title>
</head>
<body>
    <!-- Navigation Section -->
    <header class="header">
        <div><a href="./index.php"><img class="logo" src="../static/images/FitFlex.png" alt="website logo" width="70px"></a></div>
        <div class="hamburger">
            <div class="menu-btn">
                <div class="menu-btn_lines"></div>
            </div>
        </div>
        <nav>
            <div class="nav_links">
                <ul class="menu-items">
                    <li><a href="./index.php" class="menu-item">Home</a></li>
                    <li><a href="./about.php" class="menu-item">About Us</a></li>
                    <li><button class="sign-in-btn"><a href="./login.php" class="menu-item">Login</a></button></li>
                    <li><button class="sign-in-btn"><a href="./sign-up.php" class="menu-item">Sign-up</a></button></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- End of Navigation Section -->

    <!-- Body section -->
    <div class="container">
        <div class="banner-login"></div>

        <div class="right-content">
            <div class="header-wrapper">
                <div class="heading" style="color: #122331;"><h1>WELCOME BACK!</h1></div>
            </div>

            <div class="inner-container">
                <!-- Form for login -->
                <form id="loginForm" method="POST" action="login.php">
                    <?php if (!empty($error)): ?>
                        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <div><input id="email" class="input_area" name="email" type="email" placeholder="Enter your email" required></div>
                    <div><input id="password" class="input_area" name="password" type="password" placeholder="Enter your password" required></div>

                    <div class="forgot-section">
                        <div class="forgot"><a href="#" style="color: #122331;">Forgot password?</a></div>
                    </div>

                    <div class="select-role">
                        <label for="role">Select role:</label><br>
                        <input type="radio" id="trainee" name="role" value="trainee" required>
                        <label for="trainee" style="margin-right: 20px;">Trainee (Gym user)</label>
                        <input type="radio" id="gymOwner" name="role" value="gym_owner" required>
                        <label for="gymOwner">Gym Owner</label><br><br>
                    </div>

                    <div class="btn-wrapper">
                        <div><input class="submit_btn" type="submit" value="Log in"></div>
                        <div class="create"><p>Do not have an account?</p><a href="./sign-up.php">Sign-up</a></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
